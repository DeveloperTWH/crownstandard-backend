require("dotenv").config();
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const connectDB = require("./config/db");
// const cron = require("node-cron");
// const PayoutCron = require("./payout/cron/payoutCron");
// const RetryWorker = require("./payout/workers/retryWorker");


const app = express();

// 🔌 Middlewares
app.use(cors({
  origin: "https://crownstandard.netlify.app",
  credentials: true
}));

app.use("/api", require("./routes/webhookRoutes"));

app.use(express.json({ limit: "10mb" }));
app.use(morgan("dev"));


connectDB();

// ✅ Routes
app.use("/auth", require("./routes/auth.routes"));
app.use("/users", require("./routes/user.routes"));
app.use("/categories", require("./routes/category.routes"));
app.use("/service", require("./routes/service.routes"));
app.use("/providers", require("./routes/provider.routes"));
app.use("/services", require("./routes/service.public.routes"));      // public
app.use("/services", require("./routes/service.routes"));             // provider (create/update/delete/my)
app.use("/api", require("./routes/bookingRoutes"));
app.use("/api", require("./routes/paymentRoutes"));

// admin payout routes
// app.use("/api/admin/payouts", require("./payout/controllers/payoutController"));


app.get("/", (req, res) => {
  res.json({ message: "Crownstandard API is running 🚀" });
});


app.use((err, req, res, next) => {
  console.error("❌ Server Error:", err);
  res.status(500).json({ message: err.message || "Server Error" });
});


const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);

  // 🕒 Initialize payout automation
  // console.log("🧭 Initializing payout cron jobs...");

  // // Run payout cron every 1 hour
  // cron.schedule("* * * * *", async () => {
  //   console.log("🕐 Running payout cron (hourly)...");
  //   try {
  //     await PayoutCron.runPayoutCron?.();
  //     console.log("✅ Hourly payout cron finished.");
  //   } catch (err) {
  //     console.error("❌ payoutCron error:", err.message);
  //   }
  // });

  // // Run retry worker every 30 minutes
  // cron.schedule("* * * * *", async () => {
  //   console.log("♻️ Running retry worker (every 30 mins)...");
  //   try {
  //     await RetryWorker.processRetryQueue?.();
  //     console.log("✅ Retry worker finished.");
  //   } catch (err) {
  //     console.error("❌ Retry worker error:", err.message);
  //   }
  // });
});

